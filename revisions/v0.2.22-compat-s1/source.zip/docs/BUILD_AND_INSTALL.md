# 构建、安装与复现

本轮为阶段1新工作副本 s1-json-ui-20261108-01，候选0.2.22-compat-s1 /34。公开v33的原始APK和233文件输入绑定继续保留；本轮使用自己的实际输入清单、APK哈希和测试证据。不得在封存目录直接运行下面脚本。

## 在下一份新副本准备环境

先只读核对README、CURRENT_STATUS、FULL_WORKFLOW、AGENTS和最终validation；确认具体计划后，创建新的work/<唯一修订>与outputs/<同名>。复制清单内源码及经审核支持脚本，工具链和现有测试签名允许只读复用。

按source/stage-tools.example.json建立不公开的tools.local.json，配置JDK、Gradle、当前阶段SDK、模拟器工具、已有测试证书、签名环境变量名、输出根及保护根。所有Gradle缓存、SDK可写组件、Android/Java用户目录、临时目录、AVD、CXX/Gradle输出、日志和截图均在新阶段。禁止指向旧目录的可写链接或硬链接。stage-env.ps1校验目录及封存标记；stage_guard.py的明确保护范围必须适配下一修订，不能原封不动指向本轮后继续写入。

保留实际工具链：JDK17.0.16、Gradle8.11.1、AGP8.9.2、Kotlin2.1.20、NDK28.0.13004108、CMake3.22.1、Build Tools35.0.0；minSdk26、targetSdk35。先确认依赖和磁盘可用，再执行离线构建，不升级整套依赖来掩盖问题。既有测试密钥不随交付打包，不生成替代密钥。

## 构建命令形态

签名口令只由用户环境注入配置指定的进程环境变量，不写进脚本、报告或命令行明文。完整参数、环境路径映射、退出码、签名与对齐结果见build-commands-public.json；本地原始记录的哈希在证据索引。

```powershell
$ErrorActionPreference='Stop'
# $Stage、$Output均为新的、经检查的绝对路径。
. "$Stage/source/stage-env.ps1"
& "$Stage/source/build-stage.ps1" -OutputRoot $Output -BuildAbi phone
& "$Stage/source/build-stage.ps1" -OutputRoot $Output -BuildAbi arm32 -IsolationOnly -SkipLint
& "$Stage/source/build-stage.ps1" -OutputRoot $Output -BuildAbi x86_64 -IsolationOnly -SkipLint
```

脚本使用--offline、--no-daemon和当前阶段project-cache；每个外部步骤显式检查退出码，失败抛错中止。输出存在时拒绝覆盖。当前未封存修订内迭代也要保留上一迭代APK、idsig、源码输入及测试记录；封存后必须另起修订。新代码交付code递增，文档归档不增code。

手机主包仅双ARM，x86_64仅隔离构建。最终静态审计分别检查身份、签名、ABI、主包隔离入口排除、适用64位ELF LOAD对齐与最终zipalign16KB；实际ARM64/16KB运行仍须单独环境，不可替代。

## 测试脚本与设备

scripts.zip仅含明确审核脚本，script-manifest.json记录哈希。全部设备动作显式传serial、包名、APK和SHA256、源码标识与版本，设备重新核对，不能默认上一台仍在线。

- run_device.py：仅隔离包，安装/探针有超时，真实进程位数与JNI句柄释放写入证据；退出清理隔离包，不触碰主应用。
- run_ui.py：仅隔离UI，先记录再恢复字体、导航/刘海覆盖、键盘与隔离通知状态；截图需逐张人工检查，自动PASS不是系统栏视觉通过。
- matrix-suite.py、run_realme_batch.py：串行编排已约定用例，清理或恢复无法证明成功时停止后续，缺证据保留NOT_RUN/BLOCKED。
- main-device.py：只读预检、同签名覆盖安装和白名单快照。覆盖前两次核对manualOff、desired、phase及服务不存在；不调用真实连接、停止、注销或修复。
- restore_revision.py：根据匹配的本轮记录恢复隔离测试状态；模拟器退出必须核对serial、qemu、AVD及当前阶段路径，不关闭全局ADB，不删除历史AVD。

adb_client.py复用已运行的本机ADB服务127.0.0.1:5037，不创建ADB凭据。测试回环服务器在设备内部，设备127.0.0.1不是主机127.0.0.1；本轮隔离测试不需要adb reverse，不回退生产端点。若将来改用主机服务器，必须先明确reverse映射、超时和退出清理。

真实认证始终由用户操作。短时实网方案：登录最多1次、注销0次、修复0次，观察最多5分钟；只保留正常心跳和既有预算探测，代理额外网络探测0次，白名单状态快照间隔至少60秒。认证失败、网络/身份变化、用户停止或到时结束观察；不自动重登、注销或修复，不因失败追加次数。此观察不能证明持续外网、Doze或8小时锁屏表现。

## 安装和恢复边界

同签名install -r保留主应用数据，安装失败停止，不自动卸载、清数据或加降级参数。主包测试证书SHA256：2df9ad39258e06a0174c45862dbd3bf1611d566e0dead5cae43a26a213b1b229。正式签名迁移和低code回退不保证覆盖或无损数据迁移。

破坏性和故障注入只作用隔离包。不要导出主应用凭据、完整日志或抓包；从入口就使用字段白名单。用户已归因于旧客户端未注销的换机事件不重新列为APK缺陷，原始历史证据不倒改。

第三方LICENSE、NOTICE、来源及cJSON/LZMA/OkHttp/Okio声明保留。当前源码清单仅绑定source/实际输入；顶层说明和支持脚本使用独立supplement/script清单，不能混淆成原v33构建输入。
